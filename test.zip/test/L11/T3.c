#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    // Initialize the MPI environment
    MPI_Init(&argc, &argv);

    int rank, size;
    int local_value, global_sum;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    local_value = rank + 1;
    
    // &local_value: Pointer to the local value to reduce, 
    // &global_sum: Pointer to store result of reduction, 
    // 1: Number of elements to reduce, 
    // MPI_INT: Data type (integer), 
    // MPI_SUM: Reduction operation (sum), 
    // 0: Root process rank, 
    // MPI_COMM_WORLD: Communicator.
    MPI_Reduce(&local_value, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("Global sum: %d\n", global_sum);
    }

    MPI_Finalize();

    return 0;
}
