#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    int array[4] = {1, 2, 3, 4};  
    int recv_data;
    int gathered_data[4];

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // array: Pointer to the data to scatter (from root), 
    // 1: Number of elements each process receives, 
    // MPI_INT: Data type (integer), 
    // &recv_data: Pointer to store received data, 
    // 1: Number of elements each process sends, 
    // MPI_INT: Data type (integer), 
    // 0: Root process rank, 
    // MPI_COMM_WORLD: Communicator.
    MPI_Scatter(array, 1, MPI_INT, &recv_data, 1, MPI_INT, 0, MPI_COMM_WORLD);

    recv_data = recv_data * 2;
    
    // gathered_data: Pointer to store gathered data, 
    MPI_Gather(&recv_data, 1, MPI_INT, gathered_data, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("Modified array: ");
        for (int i = 0; i < size; i++) {
            printf("%d ", gathered_data[i]);
        }
        printf("\n");
    }

    MPI_Finalize();

    return 0;
}
