import requests
import argparse

def generate_text(prompt):
  """
  Sends a request to the Gemini API to generate text.

  Args:
    prompt: The prompt for the model to respond to.

  Returns:
    The generated text.
  """
  api_key = "AIzaSyBNqntJmITidOsiW2rZ_hGf8-uGQxGB89g"
  url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
  data = {"contents": [{"parts": [{"text": prompt}]}]}

  response = requests.post(url, headers={"Content-Type": "application/json"}, json=data)

  if response.status_code != 200:
    print("Error:", response.text)
    exit()

  response_data = response.json()
  return response_data["candidates"][0]["content"]["parts"][0]["text"]

if __name__ == "__main__":
  parser = argparse.ArgumentParser(description="Generate text using the Gemini API.")
  parser.add_argument("--prompt", type=str, required=True, help="The prompt for the model.")
  args = parser.parse_args()

  generated_text = generate_text(args.prompt)
  print(generated_text)
