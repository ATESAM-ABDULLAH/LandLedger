#include <mpi.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    // Initialize
    MPI_Init(&argc, &argv);

    int rank, size, number;
    const int PING_PONG_LIMIT = 5;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size != 2)// only 2 processes allowed
    {
        if (rank == 0)
        {
            printf("This program requires exactly 2 processes.\n");
        }
        MPI_Finalize();
        return 0;
    }

    if (rank == 0)
    {
        number = 10;
        for (int i = 0; i < PING_PONG_LIMIT; i++)
        {
            printf("Process 0 sent number %d to Process 1\n", number);
            MPI_Send(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);

            MPI_Recv(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Process 0 received number %d\n", number);
        }
    }
    else if (rank == 1)
    {
        for (int i = 0; i < PING_PONG_LIMIT; i++)
        {
            MPI_Recv(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Process 1 received number %d, incremented to %d, and sent it back\n", number, number + 1);

            number++;
            MPI_Send(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Finalize();

    return 0;
}
